import sys
import glob
import collections as c
import os
import re 
import json
import math
#define punctuation to be removed from tokens and documents
punct = '''[.,\/'"#!$?%\><^&\*;:{}=\-_`~()]'''
stopwords = ['a','i','or','and','the','is','to','of','but','was','will','be','were','have','had','having','has']
#read files into dictionaries
files = glob.glob(os.path.join(sys.argv[1],'*/*/*/*.txt'))
testingData = c.defaultdict(list)
trainingData = c.defaultdict(list)
for f in files:
    class1,class2,fold,filename = f.split('/')[-4:]
    trainingData[class1 + class2].append(f)
#extract tokens from training data, and decompose doc set into single list of words, to train conditional probabilities
#use mutual information to do automated feature selection on token set
tokens = []
docs = c.defaultdict(list)
words = c.defaultdict(list)
N = 0.0
t = []
d = []
p = []
n = []
for k,l in trainingData.items():
    if k.rfind('truth') >= 0:
        t += l
    if k.rfind('decep') >= 0:
        d += l
    if k.rfind('posit') >= 0:
        p += l
    if k.rfind('neg') >= 0:
        n += l
docs['truthful'] = t
docs['deceptive'] = d
docs['positive'] = p
docs['negative'] = n

for k,l in docs.items():
    for file in l:
        file = str.split(
            str.lower(
                re.sub(punct,' ',
                       open(file).read())))
        for f in file:
            words[k].append(f)
            if f not in tokens and f not in stopwords:
                tokens.append(f)    
'''
tokenCounts = []
for t in tokens:
    count = 0.0
    for l in words.values():
        for word in l:
            if t == word:
                count+=1
    tokenCounts.append((t,count))
print(tokensCounts)
'''
#train parameters. problem is composed of 2 2 class problems. first, combine classes into pos truth and deceit
params = c.defaultdict(list)

priors = []
priors.append(('truthful',float(len(docs['truthful']))/(len(docs['truthful']) + len(docs['deceptive']))))
priors.append(('deceptive',float(len(docs['deceptive']))/(len(docs['truthful']) + len(docs['deceptive']))))
priors.append(('positive',float(len(docs['positive']))/(len(docs['positive']) + len(docs['negative']))))
priors.append(('negative',float(len(docs['negative']))/(len(docs['positive']) + len(docs['negative']))))

for k,l in words.items():
    for t in tokens:
        count = 0.0
        for word in l:
            if t == word:
                count += 1 
        cond = (count + .5)/(float(len(l))+(.5 * float(len(tokens))))
        if k.rfind('truth') >= 0:
            params[t].append(('truthful',cond))
        if k.rfind('deceptive') >= 0:
            params[t].append(('deceptive',cond))
        if k.rfind('positive') >= 0:
            params[t].append(('positive',cond))
        if k.rfind('negative') >= 0:
            params[t].append(('negative',cond))
# use this file to learn naive-bayes classifier 
with open('nbmodel.txt','w') as myFile:
    json.dump(priors,myFile)
with open('nbmodel.txt','a') as myFile:
    myFile.write('\n')
    json.dump(params,myFile)
# Expected: generate nbmodel.txt


if __name__ == "main":
    model_file = "nbmodel.txt"
    input_path = str(sys.argv[1])
# use this file to classify using naive-bayes classifier 
# Expected: generate nboutput.txt

import sys
import glob
import collections as c
import os
import re
import json
import math
#define punctuation to be removed from tokens and documents
punct = '''[.,\/'"#!$?%\><^&\*;:{}=\-_`~()]'''
#read files into dictionaries--currently reserving testingdata from model tuning
files = glob.glob(os.path.join(sys.argv[1],'*/*/*/*.txt'))
testingData = c.defaultdict(list)
for f in files:
    class1,class2,fold,filename = f.split('/')[-4:]
    testingData[class1 + class2].append(f)
        
#read nbmodel.txt into parameters
filename = 'nbmodel.txt'
with open(filename, 'r') as file:
    lines = file.readlines()
    priors = json.loads(lines[0])
    params = json.loads(lines[1])
# parameters is dict with list of tuples
# priors is list of tuples
# need to make decision--logic to spit into posneg and truthdecept

result = c.defaultdict(list)
for folder,docList in testingData.items():
    for doc in docList:
        scores = []
        text = str.split(
                str.lower(
                re.sub(punct,' ',
                       open(doc).read())))
        for p in priors:
            currClass = p[0]
            score = math.log(p[1])
            for word in text:
                for l in params.get(word,''):
                    if l[0] == currClass:
                        score+= math.log(l[1])
            scores.append((currClass,score))
        if scores[0][1] > scores[1][1]:
            result[doc].append('truthful')
        else:
            result[doc].append('deceptive')
        if scores[2][1] > scores[3][1]:
            result[doc].append('positive')
        else:
            result[doc].append('negative')

with open('nboutput.txt','w') as myFile:
    for k,v in result.items():
        myFile.write('%s %s %s\n' % (v[0],v[1], k))
if __name__ == "main":
    model_file = "nbmodel.txt"
    output_file = "nboutput.txt"
    input_path = str(sys.argv[1])